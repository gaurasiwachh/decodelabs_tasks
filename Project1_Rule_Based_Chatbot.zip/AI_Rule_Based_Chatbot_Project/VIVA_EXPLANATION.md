# Viva and Presentation Preparation

## 30-Second Introduction
“My project is a Rule-Based AI Chatbot developed in Python. It takes user input, sanitizes it, identifies the intent using predefined rules, and displays a suitable response. It runs continuously until the user enters an exit command. The main concepts used are control flow, dictionaries, loops, pattern matching, fallback handling, and input normalization.”

## 2-Minute Explanation
“The purpose of this project is to understand the basic logic behind an intelligent conversational system before moving to machine learning. The chatbot follows the IPO model: Input, Process, and Output. First, the user enters a message. The program converts it to lowercase, removes punctuation, and clears extra spaces. Then it checks whether the message is an exit command. After that, it handles dynamic queries such as the current date, current time, or the user's name. For fixed questions, it performs a dictionary lookup. If no exact rule is found, it checks a few keywords. Finally, it gives a fallback response when it cannot understand the input. The chatbot stays active through a while loop and ends with a clean break command.”

## Likely Viva Questions

### 1. Why is it called rule-based?
Because the responses are controlled by rules written by the developer. The chatbot does not learn automatically.

### 2. Is this real AI?
It is a basic symbolic or rule-based form of AI. It simulates intelligent interaction but does not use machine learning.

### 3. Why did you use a dictionary?
A dictionary stores input-response pairs clearly and provides fast direct lookup. It is cleaner than writing many `if-elif` statements.

### 4. What is input sanitization?
It is the process of cleaning and normalizing input, such as converting it to lowercase, removing punctuation, and clearing extra spaces.

### 5. Why is a continuous loop required?
The loop allows the user to send multiple messages without restarting the program.

### 6. How does the program stop?
It checks for commands such as `exit`, `quit`, `bye`, `goodbye`, or `stop`, and then executes `break`.

### 7. What happens for an unknown input?
The bot returns a default fallback response.

### 8. What is the time complexity of dictionary lookup?
Average-case dictionary lookup in Python is O(1).

### 9. What are the project's limitations?
It has limited vocabulary, cannot learn, does not understand complex context, and requires manual rules.

### 10. How can it be improved?
It can be extended using NLP, machine learning, APIs, a database, voice support, or a graphical interface.

## Demonstration Order
1. Start the program.
2. Type `Hello!!!` to show sanitization.
3. Type `what is your name`.
4. Type `set my name as Pankhuri`.
5. Type `what is my name`.
6. Type `time`.
7. Enter an unknown question to show fallback.
8. Type `exit` to show clean termination.
