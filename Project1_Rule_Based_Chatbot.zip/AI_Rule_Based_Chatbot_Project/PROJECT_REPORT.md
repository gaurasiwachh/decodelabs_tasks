# INDUSTRIAL INTERNSHIP PROJECT REPORT

## Project Title
**Rule-Based Artificial Intelligence Chatbot**

## 1. Introduction
A chatbot is a software application that interacts with users through text or speech. This project implements a basic rule-based chatbot using Python. The system does not use machine learning. Instead, it follows predefined rules to identify user intent and generate an appropriate response.

## 2. Objective
The objective is to create a simple chatbot that:
- accepts user input,
- handles greetings and exit commands,
- uses control-flow and decision-making logic,
- runs continuously,
- responds to known inputs,
- and provides a fallback response for unknown inputs.

## 3. Problem Statement
Build a transparent and reliable chatbot in which the complete path from user input to output can be understood and explained.

## 4. Technologies Used
- Programming language: Python 3
- Modules: `datetime`, `random`, `re`
- Development environment: VS Code, PyCharm, IDLE, or any Python editor

## 5. System Architecture
The chatbot follows the IPO model:

1. **Input:** The user enters a message.
2. **Process:** The input is sanitized and matched with predefined rules.
3. **Output:** The chatbot displays the selected response.

The cycle repeats until the user enters an exit command.

## 6. Modules and Functions

### `sanitize_input()`
Converts input to lowercase, removes unnecessary punctuation, and normalizes spaces.

### `detect_pattern_intent()`
Recognizes dynamic commands such as setting a user's name, requesting the date, and requesting the time.

### `get_response()`
Checks exit commands, searches the dictionary, applies keyword rules, and returns a fallback response when no rule matches.

### `run()`
Creates the continuous chatbot loop and safely handles the exit operation.

## 7. Knowledge Base
The knowledge base is stored in a Python dictionary. Each key represents a recognized user input, while its value contains one or more possible responses.

Dictionary lookup is preferred over a long `if-elif` ladder because it is easier to maintain and normally provides constant-time lookup.

## 8. Algorithm
1. Start the program.
2. Display the welcome message.
3. Ask the user for input.
4. Clean and normalize the input.
5. Check whether the input is an exit command.
6. Check dynamic patterns such as name, date, or time.
7. Search for an exact response in the dictionary.
8. Apply keyword-based rules.
9. Display a fallback response if no match is found.
10. Repeat until the user exits.
11. Stop the program.

## 9. Testing
The chatbot was tested for:
- uppercase and lowercase inputs,
- extra spaces,
- punctuation,
- greetings,
- unknown commands,
- empty input,
- name storage,
- date and time queries,
- and multiple exit commands.

## 10. Advantages
- Easy to build and understand
- Predictable output
- No internet connection required
- Transparent decision-making
- Fast response for predefined inputs

## 11. Limitations
- Cannot understand every sentence
- Does not learn from conversations
- Requires manual addition of new rules
- Has limited contextual understanding
- Cannot provide live information without an API

## 12. Future Scope
The project can be extended with a GUI, database, voice support, external APIs, multilingual support, NLP, or a large language model.

## 13. Conclusion
This project demonstrates the basic foundation of artificial intelligence through deterministic decision-making. It develops practical understanding of loops, conditions, dictionaries, input sanitization, intent handling, fallback logic, and clean program termination.
