# Rule-Based AI Chatbot

## Project Overview
This project is a Python-based rule-based chatbot created for an Artificial Intelligence internship.  
It responds to predefined user inputs using deterministic rules rather than machine learning.

## Main Features
- Handles greetings and exit commands
- Runs continuously using a `while` loop
- Sanitizes input by converting it to lowercase and removing punctuation
- Uses a dictionary as a knowledge base
- Supports more than five intents
- Gives a fallback response for unknown inputs
- Tells the current date and time
- Remembers the user's name during the current session
- Handles keyboard interruption safely

## Technologies Used
- Python 3
- Built-in modules: `datetime`, `random`, and `re`
- No external library is required

## How to Run
1. Install Python 3.
2. Open a terminal in this folder.
3. Run:

```bash
python chatbot.py
```

## Example Commands
- `hello`
- `what is your name`
- `what can you do`
- `what is ai`
- `project`
- `set my name as Pankhuri`
- `what is my name`
- `time`
- `date`
- `help`
- `exit`

## Project Architecture
**Input → Sanitization → Intent Matching → Response → Repeat/Exit**

## Important Concept
This is a **white-box system** because every response rule can be inspected and explained.  
The chatbot does not learn automatically. Its knowledge is manually defined by the developer.

## Future Improvements
- Add a graphical user interface
- Store conversation history in a file
- Connect to a weather API
- Add multilingual responses
- Add speech input and output
- Upgrade to an NLP or machine-learning chatbot
