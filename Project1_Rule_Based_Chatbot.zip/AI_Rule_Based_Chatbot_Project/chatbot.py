"""
Project: Rule-Based AI Chatbot
Purpose: Industrial internship Project 1
Author: [Your Name]

This chatbot uses deterministic rules stored in dictionaries.
It demonstrates input sanitization, control flow, intent matching,
fallback handling, and a clean exit strategy.
"""

from datetime import datetime
import random
import re


class RuleBasedChatbot:
    """A simple deterministic chatbot using rule-based intent matching."""

    def __init__(self) -> None:
        self.bot_name = "Nova"
        self.user_name = None

        # Exact-match knowledge base
        self.responses = {
            "hello": ["Hello! How can I help you today?", "Hi there! What can I do for you?"],
            "hi": ["Hi! How may I assist you?", "Hello! Nice to meet you."],
            "hey": ["Hey! How can I help?", "Hey there! What would you like to know?"],
            "how are you": ["I am functioning perfectly. Thanks for asking!"],
            "what is your name": [f"My name is {self.bot_name}, your rule-based AI assistant."],
            "who are you": [f"I am {self.bot_name}, a chatbot created using Python rules."],
            "what can you do": [
                "I can greet you, tell the date or time, explain this project, "
                "remember your name during this session, and respond to basic questions."
            ],
            "help": [
                "Try: hello, what is your name, time, date, project, set my name as Rahul, "
                "what is my name, or type exit."
            ],
            "project": [
                "This is a rule-based AI chatbot. It matches sanitized user input with predefined "
                "rules and returns a deterministic response."
            ],
            "what is ai": [
                "Artificial Intelligence is the field of creating computer systems that perform "
                "tasks commonly associated with human intelligence."
            ],
            "thank you": ["You're welcome!", "Happy to help!"],
            "thanks": ["You're welcome!", "Anytime!"],
        }

        self.exit_commands = {"exit", "quit", "bye", "goodbye", "stop"}

    @staticmethod
    def sanitize_input(text: str) -> str:
        """Normalize case, remove extra spaces, and strip punctuation."""
        text = text.lower().strip()
        text = re.sub(r"[^\w\s]", "", text)
        text = re.sub(r"\s+", " ", text)
        return text

    def detect_pattern_intent(self, user_input: str):
        """Handle intents that require dynamic values or pattern matching."""
        name_match = re.fullmatch(r"(?:set my name as|my name is) ([a-zA-Z ]+)", user_input)
        if name_match:
            self.user_name = name_match.group(1).strip().title()
            return f"Nice to meet you, {self.user_name}. I will remember your name during this session."

        if user_input in {"what is my name", "do you know my name"}:
            if self.user_name:
                return f"Your name is {self.user_name}."
            return "You have not told me your name yet. Type: set my name as Rahul"

        if user_input in {"time", "what is the time", "current time"}:
            return f"The current time is {datetime.now().strftime('%I:%M %p')}."

        if user_input in {"date", "what is the date", "todays date", "today date"}:
            return f"Today's date is {datetime.now().strftime('%d %B %Y')}."

        if "weather" in user_input:
            return (
                "I am an offline rule-based chatbot, so I cannot fetch live weather data. "
                "A weather API can be added in a future version."
            )

        return None

    def get_response(self, raw_input: str) -> str:
        """Return a response for the user's message."""
        user_input = self.sanitize_input(raw_input)

        if not user_input:
            return "Please type a valid message."

        if user_input in self.exit_commands:
            return "__EXIT__"

        dynamic_response = self.detect_pattern_intent(user_input)
        if dynamic_response:
            return dynamic_response

        # Exact dictionary lookup: average O(1)
        possible_responses = self.responses.get(user_input)
        if possible_responses:
            return random.choice(possible_responses)

        # Keyword-based rules for slightly flexible matching
        if any(word in user_input.split() for word in {"hello", "hi", "hey"}):
            return "Hello! How can I assist you?"

        if "ai" in user_input and "project" in user_input:
            return (
                "The project demonstrates a white-box AI system: input is sanitized, "
                "matched against rules, and converted into a predefined output."
            )

        return (
            "I do not understand that yet. Type 'help' to see the commands I support."
        )

    def run(self) -> None:
        """Run the chatbot in a continuous loop until an exit command is entered."""
        print("=" * 62)
        print(f"{self.bot_name}: Welcome to the Rule-Based AI Chatbot")
        print("Type 'help' for commands or 'exit' to close the chatbot.")
        print("=" * 62)

        while True:
            try:
                user_message = input("You: ")
                response = self.get_response(user_message)

                if response == "__EXIT__":
                    print(f"{self.bot_name}: Goodbye! Thank you for using the chatbot.")
                    break

                print(f"{self.bot_name}: {response}")

            except KeyboardInterrupt:
                print(f"\n{self.bot_name}: Chat ended safely. Goodbye!")
                break
            except EOFError:
                print(f"\n{self.bot_name}: No more input received. Goodbye!")
                break


if __name__ == "__main__":
    chatbot = RuleBasedChatbot()
    chatbot.run()
