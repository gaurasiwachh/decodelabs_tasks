# Project 2 — Data Classification Using AI
**DecodeLabs Industrial Training Kit — Batch 2026**

## Overview
This project builds a supervised learning **classification** model that predicts the
`OrderStatus` of an e-commerce order (Cancelled / Returned / Pending / Shipped / Delivered)
from order details, using **K-Nearest Neighbors (KNN)**.

It follows the pipeline from the training brief:
`Load data → Clean/engineer features → Train/test split → Feature scaling → Train KNN → Evaluate (confusion matrix, F1-score)`

## Files
- `Project2_Data_Classification.ipynb` — main notebook, run this top to bottom
- `run_pipeline.py` — equivalent plain-script version (used to generate `/outputs`)
- `Dataset_for_Data_Analytics.xlsx` — the dataset (1,200 orders, 14 columns)
- `outputs/` — saved charts (class balance, elbow curve, confusion matrix) and a results summary
- `requirements.txt` — dependencies

## How to run
```bash
pip install -r requirements.txt
jupyter notebook Project2_Data_Classification.ipynb
```
or, without Jupyter:
```bash
python run_pipeline.py
```

## Results (this run)
- **Best K (elbow method):** 2
- **Accuracy:** 0.229
- **Weighted F1-score:** 0.208

## Why the accuracy is low — and why that's the point
With 5 roughly-equal classes, random guessing already scores ~20%. The model here lands
close to that baseline, which tells you something real: in this dataset, `OrderStatus`
isn't strongly predictable from price, product, payment method, or referral source alone.
The pipeline itself — split, scaling, training, evaluation — is correct and complete; the
low score reflects the data's actual signal, not a bug. That distinction (a working
pipeline vs. an accurate model) is exactly what the confusion matrix / F1-score step in
the brief is meant to teach.

## Possible extensions
- Try other classifiers (`LogisticRegression`, `DecisionTreeClassifier`, `RandomForestClassifier`) for comparison
- Engineer new features (e.g. days since customer's last order, if that data becomes available)
- Try predicting a different, potentially more learnable target column
